# M1S2_PJI
Projet du second semestre du Master informatique

![Retrouvez les informations utiles sur le Wiki](https://github.com/Tiplok/M1S2_PJI/wiki)